PRESCRIPTION WEB / PWA
- Open index.html through a web server (Netlify/GitHub Pages).
- Add to Android Home screen from Chrome.
- Medicine and Advice libraries are initially empty and saved in the browser.
- Codes can be used to auto-fill saved entries.
